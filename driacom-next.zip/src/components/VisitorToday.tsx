"use client";

import { useEffect, useState } from "react";

export default function VisitorToday() {
  const [count, setCount] = useState<number | null>(null);

  useEffect(() => {
    const updateFromEvent = (event: Event) => {
      const value = (event as CustomEvent<number>).detail;
      if (typeof value === "number") setCount(value);
    };

    window.addEventListener("driacom-pageview-count", updateFromEvent);

    void fetch("/api/pageview", { cache: "no-store" })
      .then((response) => (response.ok ? response.json() : null))
      .then((data: { count?: number } | null) => {
        if (typeof data?.count === "number") setCount(data.count);
      })
      .catch(() => undefined);

    return () => window.removeEventListener("driacom-pageview-count", updateFromEvent);
  }, []);

  return (
    <div className="inline-flex items-center gap-2 text-xs font-semibold text-zinc-500" title="Page views hari ini">
      <span aria-hidden="true" className="text-base">👁</span>
      <span>Pengunjung Hari Ini</span>
      <strong className="text-zinc-200">{count === null ? "—" : count.toLocaleString("id-ID")}</strong>
    </div>
  );
}
